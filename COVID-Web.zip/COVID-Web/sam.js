function hello()
{
    var name,area,mnum;
    var temp,spo2,hb;
    var date,age1;
    date=document.getElementById("date").value;
    name=document.getElementById("name").value;
    area=document.getElementById("area").value;
    temp=document.getElementById("tem").value;
    spo2=document.getElementById("sp").value;
    hb=document.getElementById("hbp").value;
    mnum=document.getElementById("numb").value;
    age1=document.getElementById("age").value;
    if(name.length<3)
    {
        text = "Please Enter valid Name";
        document.getElementById('error_name').innerHTML = text
        document.getElementById('name').style.borderColor = "red";
    }
    else{
    if(temp>37 && spo2<90)
    {
        if(hb<=60)
        {
            document.write("Name : "+name+"<br>"+"Age : "+age1+"<br>"+"Area : "+area+"<br>"+"Mobile number : "+mnum+"<br>"+"Date : "+date+"<br>"+"Temperature : "+temp+"<br>"+"SPO2 level : "+spo2+"<br>"+"Hearthbeat per minute : "+hb+"<br>"+"Your are at HIGH RISK"+"<br>"+"Follow these remedial measures: "+"<br>"+"1. Stay at home and completely isolate yourself from others "+"<br>"+"2. Get rest & stay hydrated "+"<br>"+"3. Inform your close contacts whom you were around recently"+"<br>"+" 4. Contact your local medical heath care");
        }
        else
        {
            document.write("Name : "+name+"<br>"+"Age : "+age1+"<br>"+"Area : "+area+"<br>"+"Mobile number : "+mnum+"<br>"+"Date : "+date+"<br>"+"Temperature : "+temp+"<br>"+"SPO2 level : "+spo2+"<br>"+"Hearthbeat per minute : "+hb+"<br>"+"Your are at MEDIUM RISK"+"<br>"+"Follow these remedial measures: "+"<br>"+"1. Maintain social distancing "+"<br>"+"2. Use hand sanitizers "+"<br>"+" 3.Avoid public transportation "+"<br>"+"4. Avoid touching face");
        }
    }
    else
    {
        if(hb>=60 && hb<=100)
        {
            document.write("Name : "+name+"<br>"+"Age : "+age1+"<br>"+"Area : "+area+"<br>"+"Mobile number : "+mnum+"<br>"+"Date : "+date+"<br>"+"Temperature : "+temp+"<br>"+"SPO2 level : "+spo2+"<br>"+"Hearthbeat per minute : "+hb+"<br>"+"Your are at MEDIUM RISK"+"<br>"+"Follow these remedial measures: "+"<br>"+"1. Maintain social distancing "+"<br>"+"2. Use hand sanitizers "+"<br>"+" 3.Avoid public transportation "+"<br>"+"4. Avoid touching face");
        }
        else
        {
            document.write("Name : "+name+"<br>"+"Age : "+age1+"<br>"+"Area : "+area+"<br>"+"Mobile number : "+mnum+"<br>"+"Date : "+date+"<br>"+"Temperature : "+temp+"<br>"+"SPO2 level : "+spo2+"<br>"+"Hearthbeat per minute : "+hb+"<br>"+"Your are at LOW RISK"+"<br>"+"Follow these preventive measures:"+"<br>"+"1. Maintain social distancing "+"<br>"+"2. Stay at home "+"<br>"+"3. Monitor your symptoms "+"<br>"+"4. Wash hands often");
        }
    }
    }
}