
function validateForm() {
    let x = document.forms["myForm"]["fname"].value;
    let y = document.forms["myForm"]["lname"].value;
    let z = document.forms["myForm"]["adhaar"].value;
    let p = document.forms["myForm"]["phno"].value;

    
    if (x == "" ||  y== "" ) {
      alert("Name must be filled out");
     
      return false;
    }
    if(z.length>'12' || z.length<'12'){
        alert("Invalid Adhaar Number,Enter your 12-digit Adhaar number");
        return false;
    }
    if(p.length>'10' || p.length<'10'){
        alert("Invalid Phone Number,Enter your 10-digit Phone number");
        return false;
    }
    
  }